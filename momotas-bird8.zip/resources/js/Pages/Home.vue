<script setup>
defineProps({ name: String })
</script>

<template>
  <div class="p-6">
    <h1 class="text-2xl font-bold">Hello {{ name }} 🎉</h1>
  </div>
</template>
