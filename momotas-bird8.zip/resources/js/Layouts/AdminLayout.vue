<template>

</template>

<script>
tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'ocean': '#0ea5e9',
                        'ocean-dark': '#0284c7',
                        'sand': '#f5f5dc',
                        'coral': '#ff6b6b',
                    }
                }
            }
        }
</script>