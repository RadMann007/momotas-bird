<h1>New contact from momotas-bird</h1>
<p>Name: {{ $data['name'] }}</p>
<p>Email: {{ $data['email'] }}</p>
<p>Message: {{ $data['message'] }}</p>
