<h1>Page de contact</h1>
<p>Vous pouvez nous écrire ici!</p>
<?php /**PATH D:\DEV2\momotas-bird\resources\views/contact.blade.php ENDPATH**/ ?>