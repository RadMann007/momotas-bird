<h1>New contact from momotas-bird</h1>
<p>Name: <?php echo e($data['name']); ?></p>
<p>Email: <?php echo e($data['email']); ?></p>
<p>Message: <?php echo e($data['message']); ?></p>
<?php /**PATH D:\DEV2\momotas-bird\resources\views/emails/contact.blade.php ENDPATH**/ ?>