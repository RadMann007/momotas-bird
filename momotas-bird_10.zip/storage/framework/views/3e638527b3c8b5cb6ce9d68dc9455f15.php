<h1>Page de contact</h1>
<p>Vous pouvez nous écrire ici.</p>
<?php /**PATH C:\Users\RadMann\Downloads\well-known\resources\views/contact.blade.php ENDPATH**/ ?>