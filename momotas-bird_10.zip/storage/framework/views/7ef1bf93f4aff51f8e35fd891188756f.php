<h1>Page de contact</h1>
<p>Vous pouvez nous écrire ici!</p>
<?php /**PATH /home/momotasb/public_html/resources/views/contact.blade.php ENDPATH**/ ?>