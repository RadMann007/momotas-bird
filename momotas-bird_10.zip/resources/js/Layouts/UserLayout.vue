<template>
    <div class="bg-gray-100">
            <main>
                <slot />
            </main>
        </div>
</template>